GUIDELINES FOR PROJECT [[project_id]]
----------------------


Quick info
----------
1. To compile and build this project, execute 'compile_and_build' in the
   project's root directory.
2. To run this project, execute 'run' in the project's root directory
   (after executing 'compile_and_build').
3. To run this project's unit tests, execute 'run_tests' in the project's
   root directory (after executing 'compile_and_build').
4. Obix source code files (*.osc) are located in subdirectory
   work/obix/source_code/li_[[project_id]]/


System command files
--------------------
The system command files in the project's root directory (.sh files on Unix-like
systems, and .bat files on Windows systems) are used to manage this project.
For example, you can execute the 'compile_and_build' file to compile and build
this project.
You can modify these files and/or create new system command files to meet your
specific requirements.


Obix source code files
----------------------
The root directory for Obix source code files (.osc files) is
work/obix/source_code/li_[[project_id]]/
You can create sub-libraries by creating subdirectories whose names must be
equal to the libraries' prefixed identifier, for example:
li_[[project_id]]/li_utilities/
When you run the project, the code in
work/obix/source_code/li_[[project_id]]/se_[[project_id]].osc
is executed first. Please modify this file to meet your requirements.


Java source code files
----------------------
If you want to add Java source code files (.java files) to your project
you must put them in directory
work/java/source_code/


Resource files
--------------
If this project uses resource files (e.g. image files, text translation
files, configuration files, etc.) then you must put them into directory
work/resources/
You can create sub-directories to organize your resource files.
To use these files from within your Obix or Java source code, use attribute
se_system.a_application_home_directory
to get the application's home directory which is also the root directory of
the resource files at runtime.
If you don't need resource files in your project then you can delete directory
work/resources/


Project config file
-------------------
The configuration of your project is defined in file
work/config/project_config.txt
Please look at the file content to get more information.


Additional Java libraries
-------------------------
If you want to use additional Java libraries in this project then add the
.jar files to this project by copying them into directory 
work\java\lib\ 
or by adding the .jar files' paths to file
work\java\lib\file_list.txt.
.jar files that shouldn't be deployed (because they exist already on the
target system), must be put in the 'no_deploy' sub-directory.


Additional Obix libraries
-------------------------
If you want to use additional Obix libraries in this project then add the
.oar files to this project by copying them into directory 
work\obix\lib\ 
or by adding the .oar files' paths to file
work\obix\lib\file_list.txt.
You must also add the corresponding .jar files to this project, as
described in the previous section.


Note
----
The template for this file is defined in file
[[template_file_path]]
and can be modified if needed.

Additional information can be found in the documentation at www.rps-obix.com.
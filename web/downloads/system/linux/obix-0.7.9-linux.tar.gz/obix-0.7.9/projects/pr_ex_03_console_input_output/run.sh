#!/bin/sh

# Execute this shell file to run project 'ex_03_console_input_output'

# The template for this file is defined in file F:\work\projects\obix\working\projects\pr_obix_dev\build\distribution\obix_dev\project_templates\Unix_run_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/build/distribution/ex_03_console_input_output/ex_03_console_input_output.bat" $*

read -p "Press <Enter> to continue: " tmp
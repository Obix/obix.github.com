#!/bin/sh

# Executing this file will start application 'obix_dev' on a Unix/Linux system..

# Java must be installed on your system before running this application.

# variable JAVA_DIRECTORY can be used to explicitly set the Java root directory
# used by this application
# example of explicitly setting the Java directory in case of
# using package 'openjdk-7-jdk' to install Java on Debian, Ubuntu 11.10, etc.:
# JAVA_DIRECTORY="/usr/lib/jvm/java-7-openjdk-amd64"

JAVA_DIRECTORY=""

# By default the operating system's path is used to determine the location of Java
JAVA_EXE="java"

# if the system variable JAVA_HOME is set then use it to determine the location of Java
if [ -n "$JAVA_HOME" ] ; then
	JAVA_EXE="$JAVA_HOME/bin/java"
fi

# if the local variable JAVA_DIRECTORY is set then use it to determine the location of Java
if [ -n "$JAVA_DIRECTORY" ] ; then
	JAVA_EXE="$JAVA_DIRECTORY/bin/java"
fi

THIS_DIR=$(dirname "$0")
# launch the application
"$JAVA_EXE" -Xmx384m -Xss16m -jar "$THIS_DIR/lib/obix_dev.jar" "$@"
EXIT_CODE=$?

if [ "$EXIT_CODE" = "127" ]; then
	# Java is not installed or could not be found
	THIS_FILE=$PWD/$0
	echo ""
	echo "ERROR:"
	echo "------"
	echo "'$JAVA_EXE' could not be found."
	echo "Therefore Obix cannot be executed."
	echo
	echo "To solve this problem, proceed as follows:"
	echo
	echo "   1. Check that the correct version of Java is installed on your system."
	echo "      - you can use the following system commands:"
	echo "           java -version"
	echo "           whereis java"
	echo "           which java"
	echo
	echo "   2. Ensure that at least one of the following conditions is fulfilled:"
	echo "      - The 'java' command (executable) is included in your operating"
	echo "        system's path"
	echo "      - the JAVA_HOME environment variable is properly set"
	echo "      - the JAVA_DIRECTORY variable in file"
	echo "        $THIS_FILE"
	echo "        is properly set"
	echo ""
	echo "Current settings:"
	echo "  JAVA_HOME (operating system variable): $JAVA_HOME"
	echo "  JAVA_DIRECTORY (local script variable): $JAVA_DIRECTORY"
	echo ""
	echo "You can also have a look at file"
	echo "$THIS_FILE"
	echo "to see how Obix tries to start Java."
	echo ""
	echo "Please refer also to the installation instructions on Obix's web site."
	echo ""
	echo "OBIX CANNOT BE EXECUTED!!!"
	echo "SEE ERROR MESSAGE ABOVE."
fi

exit $EXIT_CODE

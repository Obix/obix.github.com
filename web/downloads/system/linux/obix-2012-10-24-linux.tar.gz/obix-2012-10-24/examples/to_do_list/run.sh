#!/bin/sh

# Execute this shell file to run your project

THIS_DIR=$(dirname "$0")

cd "$THIS_DIR/run/to_do_list/"
bin/to_do_list.sh $*

echo -n "Press <Enter> to continue: "
read tmp
#!/bin/sh

# Execute this shell file to run your project

THIS_DIR=$(dirname "$0")

cd "$THIS_DIR/run/random_arcs/"
bin/random_arcs.sh $*

echo -n "Press <Enter> to continue: "
read tmp
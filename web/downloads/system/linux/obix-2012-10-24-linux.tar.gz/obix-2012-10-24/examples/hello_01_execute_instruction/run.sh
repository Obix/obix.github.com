#!/bin/sh

# 'execute_instruction' is an Obix command used to execute a single Obix source code instruction provided as a parameter on the command line.
# The instruction to be executed is provided as a string after the keyword 'execute_instruction'.
# 'system.console.write_line' is a service command used to display a string on the system console.
# Instead of typing 'execute_instruction' you can also simply type 'ei'.

obix execute_instruction 'system.console.write_line ( "Hello world" )'

echo -n "Press <Enter> to continue: "
read tmp
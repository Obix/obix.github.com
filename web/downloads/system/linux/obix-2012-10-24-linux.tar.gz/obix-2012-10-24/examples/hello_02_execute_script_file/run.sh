#!/bin/sh

obix hello.osc

echo -n "Press <Enter> to continue: "
read tmp
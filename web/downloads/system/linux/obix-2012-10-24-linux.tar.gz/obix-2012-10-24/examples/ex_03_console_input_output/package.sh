#!/bin/sh

# Execute this shell file to create a single compressed file to distribe your project

obix package_project

echo -n "Press <Enter> to continue: "
read tmp
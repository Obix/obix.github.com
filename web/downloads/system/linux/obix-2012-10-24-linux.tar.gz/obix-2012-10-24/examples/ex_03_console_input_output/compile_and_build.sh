#!/bin/sh

# Execute this shell file to compile and build your project

obix compile_project

if [ $? -eq 0 ] ; then
	obix build_project
fi

echo -n "Press <Enter> to continue: "
read tmp
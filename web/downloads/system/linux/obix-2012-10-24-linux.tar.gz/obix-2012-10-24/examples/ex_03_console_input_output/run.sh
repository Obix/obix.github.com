#!/bin/sh

# Execute this shell file to run your project

THIS_DIR=$(dirname "$0")

cd "$THIS_DIR/run/ex_03_console_input_output/"
bin/ex_03_console_input_output.sh $*

echo -n "Press <Enter> to continue: "
read tmp
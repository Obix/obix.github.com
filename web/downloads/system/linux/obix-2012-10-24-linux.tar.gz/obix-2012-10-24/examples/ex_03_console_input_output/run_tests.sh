#!/bin/sh

# Execute this batch file to run your project's unit tests

# Parameter 'include_path' in the command below can be used to specify which software elements should be included in the tests
# The value of this parameter is a regular expression specifying the software element's path to be matched
# For example, to test only services, write: include_path:'.*\.se_.*'

# In a similar manner you can use parameter 'exclude_path' to specify software elements that should be excluded from the tests
# For example, to exclude all factories, write: exclude_path:'.*\.fa_.*'

obix run_tests include_path:'.*' display_infos:yes
#!/bin/sh

# Execute this shell file to run your project

THIS_DIR=$(dirname "$0")

cd "$THIS_DIR/run/hello_03_PC_application/"
bin/hello_03_PC_application.sh $*

echo -n "Press <Enter> to continue: "
read tmp
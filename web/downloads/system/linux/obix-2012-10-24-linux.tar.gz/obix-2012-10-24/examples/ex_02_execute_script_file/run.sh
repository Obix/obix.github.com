#!/bin/sh

# 'create_random_numbers_file.osc' is the file that contains the source code to be executed

obix create_random_numbers_file.osc

echo -n "Press <Enter> to continue: "
read tmp
#!/bin/sh

# Executing this file will start application 'obix_dev' on a Unix/Linux system..

# Java must be installed on your system before running this application.

# By default the operating system's JAVA_HOME environment variable is used to
# determine the location of Java.
# Optionally, the location of Java can be defined by assigning a path to the
# variable JAVA_DIRECTORY below in this script. This would typically be done
# if JAVA_HOME doesn't exist (and you don't want to create it) or if you want
# to explicitly use another path in order to use another version of Java for
# running Obix.
# If JAVA_HOME and JAVA_DIRECTORY are not set then Java must be included in
# your operating system's PATH.

# example of explicitly setting the Java directory:
# JAVA_DIRECTORY="/usr/local/java/jdk1.6.0_22"

JAVA_DIRECTORY=""


THIS_FILE=$PWD/$0

JAVA_DIR=$JAVA_DIRECTORY
if [ -z $JAVA_DIR ] ; then
	if [ -n $JAVA_HOME ] ; then
		JAVA_DIR=$JAVA_HOME
	else
		echo "Note:"
		echo "   The JAVA_HOME environment variable is not set on your system."
		echo "   Therefore it is assumed that Java is installed on your system"
		echo "   and included in your operating system's PATH."
		echo "   If this assumption is false then Obix cannot be executed and"
		echo "   an error will occur."
		echo "   In that case please first verify that Java is installed on"
		echo "   your system and then ensure that at least one of the following"
		echo "   conditions is true:"
		echo "     - the JAVA_HOME environment variable is properly set"
		echo "     - java (executable file) is included in your system's PATH"
		echo "     - JAVA_DIRECTORY is explicitly set in file $THIS_FILE"
		echo "   If you don't want to display this note then please modifiy"
		echo "   file $THIS_FILE"
		echo "end of note"
	fi
fi

if [ -z $JAVA_DIR ] ; then
	JAVA_EXE="java"
else
	JAVA_EXE="$JAVA_DIR/bin/java"
fi

if [ -x "$JAVA_EXE" ] ; then
	THIS_DIR=$(dirname "$0")
	"$JAVA_EXE"  -Xmx256m -Xss16m -jar "$THIS_DIR/obix_dev.jar" $*
else
	echo "ERROR:"
	echo "------"
	echo "File $JAVA_EXE (executable) cannot be accessed."
	echo "Therefore Obix cannot be executed."
	echo "Possible causes:"
	echo "  - Java is not installed on your system"
	echo "  - the JAVA_HOME environment variable is not set or set to an invalid value"
	echo "  - the JAVA_DIRECTORY variable in file"
	echo "    $THIS_FILE"
	echo "    is not set or set to an invalid value"
	echo "Current settings:"
	echo "  JAVA_HOME: $JAVA_HOME"
	echo "  JAVA_DIRECTORY: $JAVA_DIRECTORY"
	echo "To correct the problem, you might want to have a look at file"
	echo "$THIS_FILE."
fi
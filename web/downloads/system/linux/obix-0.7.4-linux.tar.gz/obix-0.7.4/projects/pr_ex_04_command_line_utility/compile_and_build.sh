#!/bin/sh

# Execute this shell file to compile and build project 'ex_04_command_line_utility'

# The template for this file is defined in file L:\obix\working\project_templates\Unix_compile_and_build_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/../../obix.sh" compile_project project_id:ex_04_command_line_utility
if [ $? -eq 0 ] ; then
	"$THIS_DIR/../../obix.sh" build_project project_id:ex_04_command_line_utility
fi

read -p "Press <Enter> to continue: " tmp
#!/bin/sh

# Execute this shell file to run project 'ex_03_console_input_output'

# The template for this file is defined in file L:\obix\working\project_templates\Unix_run_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/build/distribution/ex_03_console_input_output.sh" $*

read -p "Press <Enter> to continue: " tmp
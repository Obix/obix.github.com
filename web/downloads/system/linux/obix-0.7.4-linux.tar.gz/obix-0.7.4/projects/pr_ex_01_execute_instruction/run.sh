#!/bin/sh

# 'obix.sh' starts Obix
# 'execute_instruction' is an Obix command used to execute a single Obix source code instruction provided as a parameter on the command line
# The instruction to be executed is provided as a string after the keyword 'execute_instruction'
# 'system.console.write_line' is a service command used to display a string on the system console
# 'se_time_of_day.current_time' is a service command that returns the current time

../../obix.sh execute_instruction 'system.console.write_line ( "Hi, current time is " & se_time_of_day.current_time.to_string )'

read -p "Press <Enter> to continue: " tmp
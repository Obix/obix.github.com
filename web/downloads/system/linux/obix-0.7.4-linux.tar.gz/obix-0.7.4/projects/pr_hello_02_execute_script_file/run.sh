#!/bin/sh

../../obix.sh execute_file hello.osc

read -p "Press <Enter> to continue: " tmp
#!/bin/sh

# Execute this shell file to compile and build project 'ex_03_console_input_output'

# The template for this file is defined in file L:\work\projects\obix\working\project_templates\Unix_compile_and_build_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/../../obix.sh" compile_project project_id:ex_03_console_input_output
if [ $? -eq 0 ] ; then
	"$THIS_DIR/../../obix.sh" build_project project_id:ex_03_console_input_output
fi

read -p "Press <Enter> to continue: " tmp
#!/bin/sh

# Execute this shell file to create a distribution for project 'ex_03_console_input_output'

# The template for this file is defined in file L:\work\projects\obix\working\project_templates\Unix_package_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/../../obix.sh" package_project project_id:ex_03_console_input_output

read -p "Press <Enter> to continue: " tmp
#!/bin/sh

# Execute this batch file to run some or all unit tests in project 'hello_03_PC_application'

# The template for this file is defined in file F:\work\projects\obix\02_working\projects\pr_obix_dev\build\distribution\obix_dev\project_templates\Unix_run_tests_sh.txt and can be modified if needed.


# Parameter 'include_path' in the command below can be used to specify which software elements should be included in the tests
# The value of this parameter is a regular expression that specifies the software element's path to be matched
# For example, to test only services, write: include_path:".*\.se_.*"

# In a similar manner you can use parameter 'exclude_path' to specify software elements that should not be included in the tests
# For example, to exclude all factories, write: exclude_path:".*\.fa_.*"

THIS_DIR=$(dirname "$0")
"$THIS_DIR/../../obix.sh" run_tests project_id:hello_03_PC_application include_path:'.*' display_infos:yes

read -p "Press <Enter> to continue: " tmp

#!/bin/sh

# Execute this shell file to create a distribution for project 'ex_05_JSP'

# The template for this file is defined in file F:\work\projects\obix\02_working\projects\pr_obix_dev\build\distribution\obix_dev\project_templates\Unix_package_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/../../obix.sh" package_project project_id:ex_05_JSP

read -p "Press <Enter> to continue: " tmp
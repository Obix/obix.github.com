#!/bin/sh

# Execute this shell file to run project 'ex_04_command_line_utility'

# The template for this file is defined in file L:\work\projects\obix\working\project_templates\Unix_run_sh.txt and can be modified if needed.

THIS_DIR=$(dirname "$0")
"$THIS_DIR/build/distribution/ex_04_command_line_utility.sh" $*

read -p "Press <Enter> to continue: " tmp
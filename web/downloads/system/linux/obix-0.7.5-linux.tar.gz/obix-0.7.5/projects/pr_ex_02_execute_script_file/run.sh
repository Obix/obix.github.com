#!/bin/sh

# 'obix.sh' starts Obix
# 'execute_file' is an Obix system command used to execute Obix source code stored in a simple text file
# 'create_random_numbers_file.osc' is the file that contains the source code to be executed

../../obix.sh execute_file create_random_numbers_file.osc

read -p "Press <Enter> to continue: " tmp
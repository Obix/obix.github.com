#!/bin/sh

# 'obix.sh' starts Obix
# 'execute_instruction' is an Obix command used to execute a single Obix source code instruction provided as a parameter on the command line
# The instruction to be executed is provided as a string after the keyword 'execute_instruction'
# 'system.console.write_line' is a service command used to display a message on the system console

../../obix.sh execute_instruction 'system.console.write_line ( "Hello world" )'

read -p "Press <Enter> to continue: " tmp
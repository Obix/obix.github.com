GUIDELINES FOR PROJECT [[project_id_suffix]]
----------------------


Quick info
----------
1. To compile and build this project, execute 'compile_and_build' in the
   project's root directory.
2. To run this web project
      - A servlet-container-server must be installed (e.g. Tomcat or Jetty)
      - Execute 'package' in the project's root directory to create a .war file
        in the 'distribution' subdirectory. Deploy this .war file to your 
        servlet container. For example, if you use Tomcat, simply copy the 
        .war file into Tomcat's 'webapps' directory.
      - Start your servlet container. Open a web browser and enter the URL
        http://127.0.0.1:8080/[[project_id_suffix]]/test_servlet
        to check if everything is ok.
        Replace 'test_servlet' with anyone of your application servlet names
        defined in file work/web/WEB-INF/web.xml
3. Obix source code files (*.osc) are located in subdirectory
   work/obix/source_code/li_[[project_id_suffix]]/
4. Web files are located in subdirectory work/web/


Directories
-----------
There are 3 subdirectories:
   work: This is the directory where you create and modify files to construct
         this project.
   build: This directory is reserved for Obix.
          It is used to build the project.
          You don't need to create or modify files in this directory.
   distribution: This directory contains a single compressed file that you use
                 to deploy this project on other PCs.
                 This deployment file is created with the 'package' command.


System command files
--------------------
The system command files in the project's root directory (.sh files on Unix-like
systems, and .bat files on Windows systems) are used to manage this project.
For example, you can execute the 'compile_and_build' file to compile and build
this project.
You can modify these files and/or create new system command files to meet your
specific requirements.


Obix source code files
----------------------
The root directory for Obix source code files (.osc files) is
work/obix/source_code/li_[[project_id_suffix]]/
You can create sub-libraries by creating subdirectories whose names must be
equal to the libraries' prefixed identifier, for example:
li_[[project_id_suffix]]/li_utilities/


Web files
---------
The root directory for web files is
work/web/
You can create any number of files and subdirectories in the web directory.
The web directory typically contains files of the following types:
   html (HTML code)
   jsp  (Java Server Pages code)
   js   (Javascript code)
   css  (CSS files)
The configuration files for your Java enterprise server (for example web.xml
and config.xml for a Tomcat server) are located in the following directories:
   work/web/META-INF/
   work/web/WEB-INF/
Please adapt the files in these directories as needed by this project, and
refer to your server's documentation for further information.


Resource files
--------------
If this project uses resource files (e.g. image files, text translation
files, configuration files, etc.) then you must put them into directory
work/resources/
You can create sub-directories to organize your resource files.
To use these files from within your Obix or Java source code, use attribute
se_system.a_application_home_directory
to get the application's home directory which is also the root directory of
the resource files at runtime.
If you don't need resource files in your project then you can delete directory
work/resources/


Additional Java libraries
-------------------------
If you want to use additional Java libraries in this project then add the
.jar files to this project by copying them into directory 
work\java\lib\ 
or by adding the .jar files' paths to file
work\java\lib\file_list.txt.
.jar files that shouldn't be deployed (because they exist already on the
target system), must be put in the 'no_deploy' sub-directory.


Additional Obix libraries
-------------------------
If you want to use additional Obix libraries in this project then add the
.oar files to this project by copying them into directory 
work\obix\lib\ 
or by adding the .oar files' paths to file
work\obix\lib\file_list.txt.
You must also add the corresponding .jar files to this project, as
described in the previous section.


Note
----
The template for this file is defined in file
[[template_file_path]]
and can be modified if needed.

Additional information can be found in the documentation at www.obix.lu.